The folder **GDPvsH** contains the shiny web application and the processed data.

The file **pwt100.xlsx** is the raw dataset.